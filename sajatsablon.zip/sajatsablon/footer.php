<footer id="colophon" class="site-footer" role="contentinfo">
    <div class="site-info">
        <?php
        printf( esc_html__( 'Készítette: %s', 'my-custom-theme' ), '<a href="https://example.com/">Te</a>' );
        ?>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
